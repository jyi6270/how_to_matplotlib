```python
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns

%matplotlib inline
```


```python
# 한글 폰트 문제 해결
import platform
from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~')

# 워닝 메시지 무시
import warnings
warnings.filterwarnings(action='ignore')

# 차트 축 <- 음수 부호 지원
import matplotlib
matplotlib.rcParams['axes.unicode_minus'] = False
```

- koweps_visualization.xlsx [실습]


```python
koweps_frm = pd.read_excel('./data/visualization_data/koweps_visualization.xlsx')
koweps_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>h12_id</th>
      <th>h12_ind</th>
      <th>h12_sn</th>
      <th>h12_merkey</th>
      <th>h_new</th>
      <th>h12_cobf</th>
      <th>p12_wgl</th>
      <th>p12_wsl</th>
      <th>p12_wgc</th>
      <th>p12_wsc</th>
      <th>...</th>
      <th>da12_326</th>
      <th>da12_327</th>
      <th>da12_328</th>
      <th>da12_6aq14</th>
      <th>da12_6aq15</th>
      <th>h12_pers_income1</th>
      <th>h12_pers_income2</th>
      <th>h12_pers_income3</th>
      <th>h12_pers_income4</th>
      <th>h12_pers_income5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>10101</td>
      <td>0</td>
      <td>NaN</td>
      <td>953.482054</td>
      <td>0.286943</td>
      <td>948.140524</td>
      <td>0.285336</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>20101</td>
      <td>0</td>
      <td>NaN</td>
      <td>1238.891352</td>
      <td>0.372835</td>
      <td>1238.891352</td>
      <td>0.372835</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>30101</td>
      <td>0</td>
      <td>NaN</td>
      <td>1282.051947</td>
      <td>0.385824</td>
      <td>1282.051947</td>
      <td>0.385824</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>40101</td>
      <td>0</td>
      <td>NaN</td>
      <td>1066.327201</td>
      <td>0.320903</td>
      <td>1066.327201</td>
      <td>0.320903</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3418.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>40101</td>
      <td>0</td>
      <td>NaN</td>
      <td>1390.617192</td>
      <td>0.418496</td>
      <td>1382.826774</td>
      <td>0.416151</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>15417</th>
      <td>9800</td>
      <td>7</td>
      <td>1</td>
      <td>98000701</td>
      <td>1</td>
      <td>NaN</td>
      <td>735.488155</td>
      <td>0.221339</td>
      <td>735.488155</td>
      <td>0.221339</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>979.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15418</th>
      <td>9800</td>
      <td>7</td>
      <td>1</td>
      <td>98000701</td>
      <td>1</td>
      <td>NaN</td>
      <td>898.395613</td>
      <td>0.270365</td>
      <td>898.395613</td>
      <td>0.270365</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15419</th>
      <td>9800</td>
      <td>7</td>
      <td>1</td>
      <td>98000701</td>
      <td>1</td>
      <td>NaN</td>
      <td>2686.353997</td>
      <td>0.808438</td>
      <td>2676.190322</td>
      <td>0.805379</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>868.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15420</th>
      <td>9800</td>
      <td>7</td>
      <td>1</td>
      <td>98000701</td>
      <td>1</td>
      <td>NaN</td>
      <td>841.651153</td>
      <td>0.253288</td>
      <td>841.651153</td>
      <td>0.253288</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>518.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15421</th>
      <td>9800</td>
      <td>7</td>
      <td>1</td>
      <td>98000701</td>
      <td>1</td>
      <td>NaN</td>
      <td>643.650245</td>
      <td>0.193702</td>
      <td>643.650245</td>
      <td>0.193702</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>15422 rows × 1191 columns</p>
</div>




```python
koweps = koweps_frm.copy()
```


```python
from IPython.display import Image
Image('./data/visualization_data/실습이미지.png', width = 700)
```




    
![png](output_5_0.png)
    




```python
koweps_subset = koweps[['h12_g3','h12_g4','h12_g10','h12_g11','h12_eco9','p1202_8aq1','h12_reg7']]
koweps_subset.rename(columns = {'h12_g3':'성별', 'h12_g4':'태어난 연도', 'h12_g10':'혼인상태',
                               'h12_g11':'종교','h12_eco9':'직종','p1202_8aq1':'일한달의 월 평균 임금',
                               'h12_reg7':'7개 권역별 지역구분'}, inplace = True)
koweps_subset
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>성별</th>
      <th>태어난 연도</th>
      <th>혼인상태</th>
      <th>종교</th>
      <th>직종</th>
      <th>일한달의 월 평균 임금</th>
      <th>7개 권역별 지역구분</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1936</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1945</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1948</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1942</td>
      <td>3</td>
      <td>1</td>
      <td>762.0</td>
      <td>108.9</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1923</td>
      <td>2</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>15417</th>
      <td>2</td>
      <td>1967</td>
      <td>1</td>
      <td>1</td>
      <td>952.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15418</th>
      <td>2</td>
      <td>1992</td>
      <td>5</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15419</th>
      <td>1</td>
      <td>1995</td>
      <td>5</td>
      <td>1</td>
      <td>521.0</td>
      <td>72.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15420</th>
      <td>2</td>
      <td>1998</td>
      <td>5</td>
      <td>1</td>
      <td>432.0</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15421</th>
      <td>1</td>
      <td>2001</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
<p>15422 rows × 7 columns</p>
</div>




```python
# 데이터 분석
# 성별의 데이터 분포 확인
# 성별을 비율순으로 정렬
# 데이터 시각화
subset_koweps['성별'].value_counts()
```




    2    8440
    1    6982
    Name: 성별, dtype: int64




```python
subset_koweps['성별'].value_counts().plot(kind='bar', rot = 0)
```




    <AxesSubplot:>




    
![png](output_8_1.png)
    



```python
# 성별을 남, 여 변경한 성별2 컬럼 새로 만들기, 시각화
subset_koweps['성별2'] = subset_koweps['성별'].apply(lambda x : '남자' if x == 1 else '여자')
subset_koweps.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>성별</th>
      <th>태어난 연도</th>
      <th>혼인상태</th>
      <th>종교</th>
      <th>직종</th>
      <th>일한달의 월 평균 임금</th>
      <th>7개 권역별 지역구분</th>
      <th>성별2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1936</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1945</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1948</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>남자</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1942</td>
      <td>3</td>
      <td>1</td>
      <td>762.0</td>
      <td>108.9</td>
      <td>1</td>
      <td>남자</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1923</td>
      <td>2</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
    </tr>
  </tbody>
</table>
</div>




```python
# np.where(): 조건에 만족하는 인덱스만 반환
subset_koweps['성별3'] = np.where(subset_koweps['성별'] == 1 , '남자', '여자')
subset_koweps.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>성별</th>
      <th>태어난 연도</th>
      <th>혼인상태</th>
      <th>종교</th>
      <th>직종</th>
      <th>일한달의 월 평균 임금</th>
      <th>7개 권역별 지역구분</th>
      <th>성별2</th>
      <th>성별3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1936</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
      <td>여자</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1945</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
      <td>여자</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1948</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>남자</td>
      <td>남자</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1942</td>
      <td>3</td>
      <td>1</td>
      <td>762.0</td>
      <td>108.9</td>
      <td>1</td>
      <td>남자</td>
      <td>남자</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1923</td>
      <td>2</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>여자</td>
      <td>여자</td>
    </tr>
  </tbody>
</table>
</div>




```python
subset_koweps['성별3'].value_counts().plot(kind='bar', rot=0)
```




    <AxesSubplot:>




    
![png](output_11_1.png)
    



```python
# 성별 분포에 따른 시각화 - bar
gender_frm = pd.DataFrame(subset_koweps['성별3'].value_counts())
gender_frm.rename(columns = {'성별3': '명'}, inplace=True)
gender_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>명</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>여자</th>
      <td>8440</td>
    </tr>
    <tr>
      <th>남자</th>
      <td>6982</td>
    </tr>
  </tbody>
</table>
</div>




```python
gender_frm.plot(kind='bar', rot=0, figsize=(15,15))

plt.grid()
plt.title('성별 빈도', weight='bold')
plt.xlabel('성별')
plt.ylabel('명')

for idx, cnt in enumerate(list(gender_frm['명'])):
    plt.text(idx, cnt, '%d명' % cnt,
            horizontalalignment = 'center',
            verticalalignment = 'bottom',
            fontsize = 15,
            color = 'red')
    
    
plt.show()
plt.close()
```


    
![png](output_13_0.png)
    



```python
# 성별 분포에 따른 시각화 - pie

plt.figure(figsize=(10,5))
plt.pie(gender_frm['명'], labels = gender_frm.index,
       autopct = '%1.1f%%',
       colors = ['pink', 'skyblue'], shadow = True,
       startangle = 90)

plt.title('성별 분포 파이 차트', size = 20, weight = 'bold')
plt.legend(loc='best')
plt.axis('equal')

plt.show()
plt.close()
```


    
![png](output_14_0.png)
    



```python
gender_frm.values
```




    array([[8440],
           [6982]], dtype=int64)



#### 성별에 따른 평균 급여 차이 분석
- 성별과 월급 데이터만 추출
- 성별을 남자, 여자로 변환
- 데이터 정제(결측값, 결측값 제거, 이상치 결측값으로 대체하고 제거)
- 시각화



```python
sex_salary_subset = subset_koweps[['성별','일한달의 월 평균 임금']]
sex_salary_subset['성별'] = sex_salary_subset['성별'].apply(lambda x : '남자' if x == 1 else '여자')
sex_salary_subset.dropna(inplace=True)
sex_salary_subset.isnull().sum()
```




    성별              0
    일한달의 월 평균 임금    0
    dtype: int64




```python
sex_salary_subset.boxplot()
```




    <AxesSubplot:>




    
![png](output_18_1.png)
    



```python
iqr = sex_salary_subset.quantile(q=0.75) - sex_salary_subset.quantile(q=0.25)
upper = sex_salary_subset.quantile(q=0.75) + 1.5 * iqr
```


```python
sex_salary_subset['일한달의 월 평균 임금'][sex_salary_subset['일한달의 월 평균 임금'] > upper['일한달의 월 평균 임금']]
```




    76        841.0
    80        691.0
    133      1800.0
    175       693.0
    244       758.0
              ...  
    14970     641.0
    15019     952.0
    15195     654.0
    15292     842.0
    15378     704.0
    Name: 일한달의 월 평균 임금, Length: 207, dtype: float64




```python
gender_salary_subset = 
gender_salary_subset['성
gender_salary_subset.isna(
gender_salary_subset.grou
gender_salary_subset.drop
gender_salary_subset.isna(
gender_salary_subset.boxp
quantile25 = 
iqr = quantile75 - 
# 이상치 - lower fence, upper fence
lower =  quantile25 - 1.5 * iqr
print('lower fence - ', lower)
upper = quantile75 + 1.5 * iqr
print('upper fence - ', upper)
print()

# 극단치 경계 값 (아래 수평선, 위 수평선)
lower_outlier = gender_salary_subset[gender_salary_subset > lower].min()
print('lower outlier - ', lower_outlier)

upper_outlier = gender_salary_subset[gender_salary_subset < upper].max()
print('upper outlier - ', upper_outlier)
print()

# 이상치 데이터 추출
gender_salary_subset_outlier = gender_salary_subset[gender_salary_subset['일한달의 평균 임금'] > upper_outlier['일한달의 평균 임금']]
display(gender_salary_subset)
print()

gender_salary_subset_outli
# 이상치를 결측값으로 변
# 결측값 있는지 확인
# 결측값 제거
gender_salary_subset.dropna(inplace= True)
print()
# 결측값 제거 확인
print(gender_salary_subset.isnull().sum())
# 시각화 -성별에 따른 평균 급여 차이를 분석 
gender_wage = gender_salary_subset.groupby('성별')['일한달의 평균 임금'].mean()
gender_wage.plot(kind='bar', rot = 0)

plt.title('성별에 따른 평균 급여 차이')
plt.xlabel('성별')
plt.ylabel('평균 급여(단위: 만원)')
plt.legend(loc = 'best')

plt.show()
plt.close()

```

#### 나이에 따른 평균 급여 변화
- 데이터 전처리(태어난 년도, 월급에 대한 컬럼 추출, 나이를 계산하여 파생변수 추가)
- 데이터 정제(결측값 확인, 결측값 제거, 이상치 결측 처리)
- 데이터 분석(나이별 따른 급여평균)
- 데이터 시각화




```python
year_salary_subset = koweps_subset[['태어난 연도', '일한달의 월 평균 임금']]

import datetime as date
year_salary_subset['나이'] = date.datetime.now().year - year_salary_subset['태어난 연도'] +1
# year_salary_subset['나이'] = 2022 - year_salary_subset['태어난 연도'] + 1
```


```python
year_salary_subset.dropna(inplace=True)
```


```python
year_salary_subset.boxplot()

plt.show()
plt.close()
```


    
![png](output_25_0.png)
    



```python
result_frm = year_salary_subset[['나이', '일한달의 월 평균 임금']].groupby('나이').mean()
result_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>일한달의 월 평균 임금</th>
    </tr>
    <tr>
      <th>나이</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>25</th>
      <td>89.333333</td>
    </tr>
    <tr>
      <th>26</th>
      <td>136.720000</td>
    </tr>
    <tr>
      <th>27</th>
      <td>140.807692</td>
    </tr>
    <tr>
      <th>28</th>
      <td>138.000000</td>
    </tr>
    <tr>
      <th>29</th>
      <td>145.652000</td>
    </tr>
  </tbody>
</table>
</div>




```python
result_frm.plot(figsize=(10,5))

plt.grid()
plt.show()
plt.close()
```


    
![png](output_27_0.png)
    


- 연령대에 따른 분포



```python
year_salary_subset['연령대'] = (year_salary_subset['나이'] // 10) *10
year_salary_subset
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>태어난 연도</th>
      <th>일한달의 월 평균 임금</th>
      <th>나이</th>
      <th>연령대</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>1942</td>
      <td>108.9</td>
      <td>81</td>
      <td>80</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1940</td>
      <td>20.0</td>
      <td>83</td>
      <td>80</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1978</td>
      <td>322.0</td>
      <td>45</td>
      <td>40</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1975</td>
      <td>120.0</td>
      <td>48</td>
      <td>40</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1975</td>
      <td>300.0</td>
      <td>48</td>
      <td>40</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>15400</th>
      <td>1966</td>
      <td>230.0</td>
      <td>57</td>
      <td>50</td>
    </tr>
    <tr>
      <th>15401</th>
      <td>1962</td>
      <td>138.0</td>
      <td>61</td>
      <td>60</td>
    </tr>
    <tr>
      <th>15404</th>
      <td>1993</td>
      <td>286.0</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>15412</th>
      <td>1956</td>
      <td>179.0</td>
      <td>67</td>
      <td>60</td>
    </tr>
    <tr>
      <th>15419</th>
      <td>1995</td>
      <td>72.0</td>
      <td>28</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
<p>4507 rows × 4 columns</p>
</div>




```python
year_salary_subset['연령대'].value_counts()
```




    50    1159
    40    1110
    60     767
    30     748
    70     371
    80     205
    20     134
    90      13
    Name: 연령대, dtype: int64




```python
year_salary_subset.isnull().sum()
```




    태어난 연도          0
    일한달의 월 평균 임금    0
    나이              0
    연령대             0
    dtype: int64




```python
result_frm = pd.DataFrame( year_salary_subset['연령대'].value_counts())
result_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>연령대</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>50</th>
      <td>1159</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1110</td>
    </tr>
    <tr>
      <th>60</th>
      <td>767</td>
    </tr>
    <tr>
      <th>30</th>
      <td>748</td>
    </tr>
    <tr>
      <th>70</th>
      <td>371</td>
    </tr>
    <tr>
      <th>80</th>
      <td>205</td>
    </tr>
    <tr>
      <th>20</th>
      <td>134</td>
    </tr>
    <tr>
      <th>90</th>
      <td>13</td>
    </tr>
  </tbody>
</table>
</div>




```python
result_frm.plot(kind = 'bar', figsize=(10,5), rot = 0)

plt.title('연령대 분석', weight = 'bold', color = 'red')
plt.xlabel('연령대')
plt.ylabel('명')
plt.legend(loc = 'best')


for idx, value in enumerate(list(result_frm['연령대'])):
    txt = '%d명' % value
    plt.text(idx, value, txt,
            horizontalalignment = 'center',
            verticalalignment = 'bottom',
            fontsize = 10,
            color = 'red')

plt.show()
plt.close()
```


    
![png](output_33_0.png)
    


- 연령대별 평균 급여 변화

성별과 연령대 분포 

성별과 연령대에 따른 평균 급여 변화

지역별 연령층 분포와 연령층별 지역비율



```python
# 이상치 - IQR
IQR = year_salary_subset['일한달의 월 평균 임금'].quantile(q=0.75) - year_salary_subset['일한달의 평균 임금'].quantile(q=0.25)
print('IQR - ', IQR)
# 이상치 - lower fence, upper fence
lower =  year_salary_subset['일한달의 월 평균 임금'].quantile(q=0.25) - 1.5*IQR
print('lower fence - ', lower)
upper = year_salary_subset['일한달의 월 평균 임금'].quantile(q=0.75) + 1.5*IQR 
print('upper fence - ', upper)
print()

```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    File ~\anaconda3\lib\site-packages\pandas\core\indexes\base.py:3621, in Index.get_loc(self, key, method, tolerance)
       3620 try:
    -> 3621     return self._engine.get_loc(casted_key)
       3622 except KeyError as err:
    

    File ~\anaconda3\lib\site-packages\pandas\_libs\index.pyx:136, in pandas._libs.index.IndexEngine.get_loc()
    

    File ~\anaconda3\lib\site-packages\pandas\_libs\index.pyx:163, in pandas._libs.index.IndexEngine.get_loc()
    

    File pandas\_libs\hashtable_class_helper.pxi:5198, in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    File pandas\_libs\hashtable_class_helper.pxi:5206, in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: '일한달의 평균 임금'

    
    The above exception was the direct cause of the following exception:
    

    KeyError                                  Traceback (most recent call last)

    Input In [104], in <cell line: 2>()
          1 # 이상치 - IQR
    ----> 2 IQR = year_salary_subset['일한달의 월 평균 임금'].quantile(q=0.75) - year_salary_subset['일한달의 평균 임금'].quantile(q=0.25)
          3 print('IQR - ', IQR)
          4 # 이상치 - lower fence, upper fence
    

    File ~\anaconda3\lib\site-packages\pandas\core\frame.py:3505, in DataFrame.__getitem__(self, key)
       3503 if self.columns.nlevels > 1:
       3504     return self._getitem_multilevel(key)
    -> 3505 indexer = self.columns.get_loc(key)
       3506 if is_integer(indexer):
       3507     indexer = [indexer]
    

    File ~\anaconda3\lib\site-packages\pandas\core\indexes\base.py:3623, in Index.get_loc(self, key, method, tolerance)
       3621     return self._engine.get_loc(casted_key)
       3622 except KeyError as err:
    -> 3623     raise KeyError(key) from err
       3624 except TypeError:
       3625     # If we have a listlike key, _check_indexing_error will raise
       3626     #  InvalidIndexError. Otherwise we fall through and re-raise
       3627     #  the TypeError.
       3628     self._check_indexing_error(key)
    

    KeyError: '일한달의 평균 임금'



```python
# 극단치 경계 값 (아래 수평선, 위 수평선)
lower_outlier = year_salary_subset[year_salary_subset > lower].min()
print('lower outlier - ', lower_outlier['일한달의 월 평균 임금'])

upper_outlier = year_salary_subset[year_salary_subset < upper].max()
print('upper outlier - ', upper_outlier['일한달의 월 평균 임금'])
print()

```

    lower outlier -  0.0
    upper outlier -  634.0
    
    


```python
# 이상치 데이터 추출
koweps_age_outlier = year_salary_subset[year_salary_subset['일한달의 월 평균 임금'] > upper_outlier['일한달의 월 평균 임금']]
display(koweps_age_outlier)
print()

# 이상치를 결측값으로 변경
for idx in koweps_age_outlier.index :
    year_salary_subset.loc[idx, '일한달의 월 평균 임금'] = np.NaN

# 결측값 있는지 확인
print(year_salary_subset.isnull().sum())
print()
# 결측값 제거
year_salary_subset.dropna(inplace= True)
print()
print(year_salary_subset.isnull().sum())

```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>태어난 연도</th>
      <th>일한달의 월 평균 임금</th>
      <th>나이</th>
      <th>연령대</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>76</th>
      <td>1968</td>
      <td>841.0</td>
      <td>55</td>
      <td>50</td>
    </tr>
    <tr>
      <th>80</th>
      <td>1973</td>
      <td>691.0</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>133</th>
      <td>1956</td>
      <td>1800.0</td>
      <td>67</td>
      <td>60</td>
    </tr>
    <tr>
      <th>175</th>
      <td>1975</td>
      <td>693.0</td>
      <td>48</td>
      <td>40</td>
    </tr>
    <tr>
      <th>244</th>
      <td>1979</td>
      <td>758.0</td>
      <td>44</td>
      <td>40</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>14970</th>
      <td>1977</td>
      <td>641.0</td>
      <td>46</td>
      <td>40</td>
    </tr>
    <tr>
      <th>15019</th>
      <td>1976</td>
      <td>952.0</td>
      <td>47</td>
      <td>40</td>
    </tr>
    <tr>
      <th>15195</th>
      <td>1965</td>
      <td>654.0</td>
      <td>58</td>
      <td>50</td>
    </tr>
    <tr>
      <th>15292</th>
      <td>1973</td>
      <td>842.0</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>15378</th>
      <td>1969</td>
      <td>704.0</td>
      <td>54</td>
      <td>50</td>
    </tr>
  </tbody>
</table>
<p>207 rows × 4 columns</p>
</div>


    
    태어난 연도            0
    일한달의 월 평균 임금    207
    나이                0
    연령대               0
    dtype: int64
    
    
    태어난 연도          0
    일한달의 월 평균 임금    0
    나이              0
    연령대             0
    dtype: int64
    


```python
#시각화 
year_salary_subset[['연령대', '일한달의 월 평균 임금']].groupby('연령대').mean().plot(kind='line', rot=0, figsize =(10,5), marker = 'o')



plt.title('연령대별 평균 급여 변화')
plt.xlabel('연령대')
plt.ylabel('평균 급여(단위: 만원)')
plt.legend(loc = 'best')

plt.show()
plt.close()

```


    
![png](output_38_0.png)
    



```python
visualization_frm = year_salary_subset[['연령대', '일한달의 월 평균 임금']].groupby('연령대').mean()
visualization_frm.plot(kind='line', rot=0, figsize =(10,5), marker = 'o')

for idx, value in enumerate(list( visualization_frm['일한달의 월 평균 임금'] )) :
    txt = '%d명' % value
    
    plt.text(visualization_frm.index[idx], value, txt , 
            horizontalalignment='center',
            verticalalignment='bottom',
            fontsize=10,
            color='red')
    

plt.title('연령대별 평균 급여 변화')
plt.xlabel('연령대')
plt.ylabel('평균 급여(단위: 만원)')
plt.legend(loc = 'best')

plt.show()
plt.close()

```


    
![png](output_39_0.png)
    



```python

```


```python

```
