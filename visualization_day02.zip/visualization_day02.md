```python
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

%matplotlib inline
```


```python
# 한글 폰트 문제 해결
import platform
from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~')

# 워닝 메시지 무시
import warnings
warnings.filterwarnings(action='ignore')

# 차트 축 <- 음수 부호 지원
import matplotlib
matplotlib.rcParams['axes.unicode_minus'] = False
```


```python
tmp_frm = pd.read_excel('./data/visualization_data/시도별 전출입 인구수.xlsx' , 
                        header = 0)

tmp_frm = tmp_frm.fillna(method='ffill')
seoul_frm = tmp_frm[ (tmp_frm['전출지별'] == '서울특별시') & (tmp_frm['전입지별'] != '서울특별시') ]
seoul_frm.drop(['전출지별'] , axis = 1 , inplace = True) 
seoul_frm.rename({'전입지별' : '전입지'}, axis = 1 , inplace = True)
seoul_frm.set_index('전입지' , inplace = True)
seoul_frm

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>1978</th>
      <th>1979</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>전입지</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>전국</th>
      <td>1448985.0</td>
      <td>1419016.0</td>
      <td>1210559.0</td>
      <td>1647268.0</td>
      <td>1819660.0</td>
      <td>2937093.0</td>
      <td>2495620.0</td>
      <td>2678007.0</td>
      <td>3028911.0</td>
      <td>2441242.0</td>
      <td>...</td>
      <td>2083352.0</td>
      <td>1925452.0</td>
      <td>1848038.0</td>
      <td>1834806.0</td>
      <td>1658928.0</td>
      <td>1620640.0</td>
      <td>1661425.0</td>
      <td>1726687.0</td>
      <td>1655859.0</td>
      <td>1571423.0</td>
    </tr>
    <tr>
      <th>부산광역시</th>
      <td>11568.0</td>
      <td>11130.0</td>
      <td>11768.0</td>
      <td>16307.0</td>
      <td>22220.0</td>
      <td>27515.0</td>
      <td>23732.0</td>
      <td>27213.0</td>
      <td>29856.0</td>
      <td>28542.0</td>
      <td>...</td>
      <td>17353.0</td>
      <td>17738.0</td>
      <td>17418.0</td>
      <td>18816.0</td>
      <td>16135.0</td>
      <td>16153.0</td>
      <td>17320.0</td>
      <td>17009.0</td>
      <td>15062.0</td>
      <td>14484.0</td>
    </tr>
    <tr>
      <th>대구광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>9720.0</td>
      <td>10464.0</td>
      <td>10277.0</td>
      <td>10397.0</td>
      <td>10135.0</td>
      <td>10631.0</td>
      <td>10062.0</td>
      <td>10191.0</td>
      <td>9623.0</td>
      <td>8891.0</td>
    </tr>
    <tr>
      <th>인천광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>50493.0</td>
      <td>45392.0</td>
      <td>46082.0</td>
      <td>51641.0</td>
      <td>49640.0</td>
      <td>47424.0</td>
      <td>43212.0</td>
      <td>44915.0</td>
      <td>43745.0</td>
      <td>40485.0</td>
    </tr>
    <tr>
      <th>광주광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>10846.0</td>
      <td>11725.0</td>
      <td>11095.0</td>
      <td>10587.0</td>
      <td>10154.0</td>
      <td>9129.0</td>
      <td>9759.0</td>
      <td>9216.0</td>
      <td>8354.0</td>
      <td>7932.0</td>
    </tr>
    <tr>
      <th>대전광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>13515.0</td>
      <td>13632.0</td>
      <td>13819.0</td>
      <td>13900.0</td>
      <td>14080.0</td>
      <td>13440.0</td>
      <td>13403.0</td>
      <td>13453.0</td>
      <td>12619.0</td>
      <td>11815.0</td>
    </tr>
    <tr>
      <th>울산광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>5057.0</td>
      <td>4845.0</td>
      <td>4742.0</td>
      <td>5188.0</td>
      <td>5691.0</td>
      <td>5542.0</td>
      <td>6047.0</td>
      <td>5950.0</td>
      <td>5102.0</td>
      <td>4260.0</td>
    </tr>
    <tr>
      <th>세종특별자치시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>2998.0</td>
      <td>2851.0</td>
      <td>6481.0</td>
      <td>7550.0</td>
      <td>5943.0</td>
      <td>5813.0</td>
    </tr>
    <tr>
      <th>경기도</th>
      <td>130149.0</td>
      <td>150313.0</td>
      <td>93333.0</td>
      <td>143234.0</td>
      <td>149045.0</td>
      <td>253705.0</td>
      <td>202276.0</td>
      <td>207722.0</td>
      <td>237684.0</td>
      <td>278411.0</td>
      <td>...</td>
      <td>412408.0</td>
      <td>398282.0</td>
      <td>410735.0</td>
      <td>373771.0</td>
      <td>354135.0</td>
      <td>340801.0</td>
      <td>332785.0</td>
      <td>359337.0</td>
      <td>370760.0</td>
      <td>342433.0</td>
    </tr>
    <tr>
      <th>강원도</th>
      <td>9352.0</td>
      <td>12885.0</td>
      <td>13561.0</td>
      <td>16481.0</td>
      <td>15479.0</td>
      <td>27837.0</td>
      <td>25927.0</td>
      <td>25415.0</td>
      <td>26700.0</td>
      <td>27599.0</td>
      <td>...</td>
      <td>23668.0</td>
      <td>23331.0</td>
      <td>22736.0</td>
      <td>23624.0</td>
      <td>22332.0</td>
      <td>20601.0</td>
      <td>21173.0</td>
      <td>22659.0</td>
      <td>21590.0</td>
      <td>21016.0</td>
    </tr>
    <tr>
      <th>충청북도</th>
      <td>6700.0</td>
      <td>9457.0</td>
      <td>10853.0</td>
      <td>12617.0</td>
      <td>11786.0</td>
      <td>21073.0</td>
      <td>18029.0</td>
      <td>17478.0</td>
      <td>18420.0</td>
      <td>20047.0</td>
      <td>...</td>
      <td>15294.0</td>
      <td>15295.0</td>
      <td>15461.0</td>
      <td>15318.0</td>
      <td>14555.0</td>
      <td>13783.0</td>
      <td>14244.0</td>
      <td>14379.0</td>
      <td>14087.0</td>
      <td>13302.0</td>
    </tr>
    <tr>
      <th>충청남도</th>
      <td>15954.0</td>
      <td>18943.0</td>
      <td>23406.0</td>
      <td>27139.0</td>
      <td>25509.0</td>
      <td>51205.0</td>
      <td>41447.0</td>
      <td>43993.0</td>
      <td>48091.0</td>
      <td>45388.0</td>
      <td>...</td>
      <td>27458.0</td>
      <td>24889.0</td>
      <td>24522.0</td>
      <td>24723.0</td>
      <td>22269.0</td>
      <td>21486.0</td>
      <td>21473.0</td>
      <td>22299.0</td>
      <td>21741.0</td>
      <td>21020.0</td>
    </tr>
    <tr>
      <th>전라북도</th>
      <td>10814.0</td>
      <td>13192.0</td>
      <td>16583.0</td>
      <td>18642.0</td>
      <td>16647.0</td>
      <td>34411.0</td>
      <td>29835.0</td>
      <td>28444.0</td>
      <td>29676.0</td>
      <td>31570.0</td>
      <td>...</td>
      <td>18390.0</td>
      <td>18332.0</td>
      <td>17569.0</td>
      <td>17755.0</td>
      <td>16120.0</td>
      <td>14909.0</td>
      <td>14566.0</td>
      <td>14835.0</td>
      <td>13835.0</td>
      <td>13179.0</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>10513.0</td>
      <td>16755.0</td>
      <td>20157.0</td>
      <td>22160.0</td>
      <td>21314.0</td>
      <td>46610.0</td>
      <td>46251.0</td>
      <td>43430.0</td>
      <td>44624.0</td>
      <td>47934.0</td>
      <td>...</td>
      <td>16601.0</td>
      <td>17468.0</td>
      <td>16429.0</td>
      <td>15974.0</td>
      <td>14765.0</td>
      <td>14187.0</td>
      <td>14591.0</td>
      <td>14598.0</td>
      <td>13065.0</td>
      <td>12426.0</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>11868.0</td>
      <td>16459.0</td>
      <td>22073.0</td>
      <td>27531.0</td>
      <td>26902.0</td>
      <td>46177.0</td>
      <td>40376.0</td>
      <td>41155.0</td>
      <td>42940.0</td>
      <td>43565.0</td>
      <td>...</td>
      <td>15425.0</td>
      <td>16569.0</td>
      <td>16042.0</td>
      <td>15818.0</td>
      <td>15191.0</td>
      <td>14420.0</td>
      <td>14456.0</td>
      <td>15113.0</td>
      <td>14236.0</td>
      <td>12464.0</td>
    </tr>
    <tr>
      <th>경상남도</th>
      <td>8409.0</td>
      <td>10001.0</td>
      <td>11263.0</td>
      <td>15193.0</td>
      <td>16771.0</td>
      <td>23150.0</td>
      <td>22400.0</td>
      <td>27393.0</td>
      <td>28697.0</td>
      <td>30183.0</td>
      <td>...</td>
      <td>15438.0</td>
      <td>15303.0</td>
      <td>15689.0</td>
      <td>16039.0</td>
      <td>14474.0</td>
      <td>14447.0</td>
      <td>14799.0</td>
      <td>15220.0</td>
      <td>13717.0</td>
      <td>12692.0</td>
    </tr>
    <tr>
      <th>제주특별자치도</th>
      <td>1039.0</td>
      <td>1325.0</td>
      <td>1617.0</td>
      <td>2456.0</td>
      <td>2261.0</td>
      <td>3440.0</td>
      <td>3623.0</td>
      <td>3551.0</td>
      <td>3937.0</td>
      <td>4261.0</td>
      <td>...</td>
      <td>5473.0</td>
      <td>5332.0</td>
      <td>5714.0</td>
      <td>6133.0</td>
      <td>6954.0</td>
      <td>7828.0</td>
      <td>9031.0</td>
      <td>10434.0</td>
      <td>10465.0</td>
      <td>10404.0</td>
    </tr>
  </tbody>
</table>
<p>17 rows × 48 columns</p>
</div>



- area plot


```python
# 충청남도, 경상북도, 강원도, 전라남도 인구 데이터만 선택
# 컬럼 인덱스는 1970 ~ 2017
seoul_frm.columns = seoul_frm.columns.astype('int')
subset_frm = seoul_frm.loc[['충청남도','경상북도','강원도','전라남도'], :]
subset_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>1978</th>
      <th>1979</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>전입지</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>충청남도</th>
      <td>15954.0</td>
      <td>18943.0</td>
      <td>23406.0</td>
      <td>27139.0</td>
      <td>25509.0</td>
      <td>51205.0</td>
      <td>41447.0</td>
      <td>43993.0</td>
      <td>48091.0</td>
      <td>45388.0</td>
      <td>...</td>
      <td>27458.0</td>
      <td>24889.0</td>
      <td>24522.0</td>
      <td>24723.0</td>
      <td>22269.0</td>
      <td>21486.0</td>
      <td>21473.0</td>
      <td>22299.0</td>
      <td>21741.0</td>
      <td>21020.0</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>11868.0</td>
      <td>16459.0</td>
      <td>22073.0</td>
      <td>27531.0</td>
      <td>26902.0</td>
      <td>46177.0</td>
      <td>40376.0</td>
      <td>41155.0</td>
      <td>42940.0</td>
      <td>43565.0</td>
      <td>...</td>
      <td>15425.0</td>
      <td>16569.0</td>
      <td>16042.0</td>
      <td>15818.0</td>
      <td>15191.0</td>
      <td>14420.0</td>
      <td>14456.0</td>
      <td>15113.0</td>
      <td>14236.0</td>
      <td>12464.0</td>
    </tr>
    <tr>
      <th>강원도</th>
      <td>9352.0</td>
      <td>12885.0</td>
      <td>13561.0</td>
      <td>16481.0</td>
      <td>15479.0</td>
      <td>27837.0</td>
      <td>25927.0</td>
      <td>25415.0</td>
      <td>26700.0</td>
      <td>27599.0</td>
      <td>...</td>
      <td>23668.0</td>
      <td>23331.0</td>
      <td>22736.0</td>
      <td>23624.0</td>
      <td>22332.0</td>
      <td>20601.0</td>
      <td>21173.0</td>
      <td>22659.0</td>
      <td>21590.0</td>
      <td>21016.0</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>10513.0</td>
      <td>16755.0</td>
      <td>20157.0</td>
      <td>22160.0</td>
      <td>21314.0</td>
      <td>46610.0</td>
      <td>46251.0</td>
      <td>43430.0</td>
      <td>44624.0</td>
      <td>47934.0</td>
      <td>...</td>
      <td>16601.0</td>
      <td>17468.0</td>
      <td>16429.0</td>
      <td>15974.0</td>
      <td>14765.0</td>
      <td>14187.0</td>
      <td>14591.0</td>
      <td>14598.0</td>
      <td>13065.0</td>
      <td>12426.0</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 48 columns</p>
</div>




```python
t_seoul_frm = subset_frm.T
t_seoul_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>전입지</th>
      <th>충청남도</th>
      <th>경상북도</th>
      <th>강원도</th>
      <th>전라남도</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1970</th>
      <td>15954.0</td>
      <td>11868.0</td>
      <td>9352.0</td>
      <td>10513.0</td>
    </tr>
    <tr>
      <th>1971</th>
      <td>18943.0</td>
      <td>16459.0</td>
      <td>12885.0</td>
      <td>16755.0</td>
    </tr>
    <tr>
      <th>1972</th>
      <td>23406.0</td>
      <td>22073.0</td>
      <td>13561.0</td>
      <td>20157.0</td>
    </tr>
    <tr>
      <th>1973</th>
      <td>27139.0</td>
      <td>27531.0</td>
      <td>16481.0</td>
      <td>22160.0</td>
    </tr>
    <tr>
      <th>1974</th>
      <td>25509.0</td>
      <td>26902.0</td>
      <td>15479.0</td>
      <td>21314.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# area plot
t_seoul_frm.plot(kind = 'area', figsize=(20,10), alpha=0.5)
plt.title('서울 -> 권역 이동', size = 30, color = 'brown', weight='bold')
plt.ylabel('이동 인구 수', size = 20, color = 'blue')
plt.xlabel('연도', size = 20)
plt.legend(loc='best', fontsize= 15)

plt.show()
plt.close()
```


    
![png](output_6_0.png)
    


- bubble plot


```python
mpg_frm = pd.read_excel('./data/visualization_data/mpg_visualization.xlsx',
                       header = 0,
                       index_col = 0)
```


```python
mpg_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>manufacturer</th>
      <th>model</th>
      <th>displ</th>
      <th>year</th>
      <th>cyl</th>
      <th>trans</th>
      <th>drv</th>
      <th>cty</th>
      <th>hwy</th>
      <th>fl</th>
      <th>class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>18</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
    </tr>
    <tr>
      <th>2</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>21</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>manual(m6)</td>
      <td>f</td>
      <td>20</td>
      <td>31</td>
      <td>p</td>
      <td>compact</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>auto(av)</td>
      <td>f</td>
      <td>21</td>
      <td>30</td>
      <td>p</td>
      <td>compact</td>
    </tr>
    <tr>
      <th>5</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.8</td>
      <td>1999</td>
      <td>6</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>16</td>
      <td>26</td>
      <td>p</td>
      <td>compact</td>
    </tr>
  </tbody>
</table>
</div>




```python
auto_mpg_frm = pd.read_csv('./data/visualization_data/auto-mpg.csv',
                       header = None)
auto_mpg_frm.columns = ['mpg','cylinders','displacement','horsepower','weight',
                        'acceleration','model year','origin','name']
auto_mpg_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model year</th>
      <th>origin</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18.0</td>
      <td>8</td>
      <td>307.0</td>
      <td>130.0</td>
      <td>3504.0</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
      <td>chevrolet chevelle malibu</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.0</td>
      <td>8</td>
      <td>350.0</td>
      <td>165.0</td>
      <td>3693.0</td>
      <td>11.5</td>
      <td>70</td>
      <td>1</td>
      <td>buick skylark 320</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18.0</td>
      <td>8</td>
      <td>318.0</td>
      <td>150.0</td>
      <td>3436.0</td>
      <td>11.0</td>
      <td>70</td>
      <td>1</td>
      <td>plymouth satellite</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16.0</td>
      <td>8</td>
      <td>304.0</td>
      <td>150.0</td>
      <td>3433.0</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
      <td>amc rebel sst</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17.0</td>
      <td>8</td>
      <td>302.0</td>
      <td>140.0</td>
      <td>3449.0</td>
      <td>10.5</td>
      <td>70</td>
      <td>1</td>
      <td>ford torino</td>
    </tr>
  </tbody>
</table>
</div>




```python
cylinders_size = auto_mpg_frm.cylinders / auto_mpg_frm.cylinders.max() * 300
print('type - ', type(cylinders_size))
print('data - ')
print(cylinders_size)
```

    type -  <class 'pandas.core.series.Series'>
    data - 
    0      300.0
    1      300.0
    2      300.0
    3      300.0
    4      300.0
           ...  
    393    150.0
    394    150.0
    395    150.0
    396    150.0
    397    150.0
    Name: cylinders, Length: 398, dtype: float64
    


```python
auto_mpg_frm.plot(kind = 'scatter', x = 'weight', y = 'mpg',
                 color = 'coral', figsize = (10,5), alpha = 0.5,
                 s = cylinders_size)

plt.savefig('./data/visualization_data/scatter.png')
plt.show()
plt.close()
```


    
![png](output_12_0.png)
    



```python
# 양적 자료의 데이터 분포 확인 - boxplot

mpg_frm.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 234 entries, 1 to 234
    Data columns (total 11 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   manufacturer  234 non-null    object 
     1   model         234 non-null    object 
     2   displ         234 non-null    float64
     3   year          234 non-null    int64  
     4   cyl           234 non-null    int64  
     5   trans         234 non-null    object 
     6   drv           234 non-null    object 
     7   cty           234 non-null    int64  
     8   hwy           234 non-null    int64  
     9   fl            234 non-null    object 
     10  class         234 non-null    object 
    dtypes: float64(1), int64(4), object(6)
    memory usage: 21.9+ KB
    


```python
mpg_frm[['displ', 'cyl', 'cty', 'hwy']].boxplot()

plt.show()
plt.close()
```


    
![png](output_14_0.png)
    



```python
# 질적 자료에 대한 데이터 빈도 확인 - value_counts()

mpg_frm['manufacturer'].value_counts()
```




    dodge         37
    toyota        34
    volkswagen    27
    ford          25
    chevrolet     19
    audi          18
    hyundai       14
    subaru        14
    nissan        13
    honda          9
    jeep           8
    pontiac        5
    land rover     4
    mercury        4
    lincoln        3
    Name: manufacturer, dtype: int64




```python
# 문제01]
# 자동차 배기량(displ)에 따라 고속도로 연비(hwy)가 다른지를 알아보자
# 배기량이 4 이하인 자동차화 5이상인 자동차 중 어떤 자동차의 고속도로연비가 평균적으로 
# 높은지 알아보자

print(mpg_frm[mpg_frm['displ']<=4]['hwy'].mean())
print(mpg_frm[mpg_frm['displ']>=5]['hwy'].mean())
print()

print(mpg_frm.query('displ <= 4')['hwy'].mean())
print(mpg_frm.query('displ >= 5')['hwy'].mean())
```

    25.96319018404908
    18.07894736842105
    
    25.96319018404908
    18.07894736842105
    


```python
# 문제 02]
# 자동차 제조 회사에 따라 도시 연비가 다른지 알아보려고 한다. 
# audi와 toyota 중 어느 manufacturer(자동차 제조 회사)의 cty(도시연비)가 평균적으로 더 높은지 알아보시오.
print(mpg_frm[mpg_frm['manufacturer']=='audi']['cty'].mean())
print(mpg_frm[mpg_frm['manufacturer']=='toyota']['cty'].mean())
```

    17.61111111111111
    18.529411764705884
    


```python
# 문제 03]
# chevrolet, ford, honda 자동차의 고속도로 연비 평균을 알아보려고 한다. 
# 이 회사들의 데이터를 추출한 후 hwy 전체 평균을 확인하시오.
print(mpg_frm[mpg_frm['manufacturer']=='chevrolet']['hwy'].mean())
print(mpg_frm[mpg_frm['manufacturer']=='ford']['hwy'].mean())
print(mpg_frm[mpg_frm['manufacturer']=='honda']['hwy'].mean())

manufacturer_list = ['chevrolet', 'ford', 'honda']
print(mpg_frm.query('manufacturer in @manufacturer_list')['hwy'].mean())
```

    21.894736842105264
    19.36
    32.55555555555556
    22.50943396226415
    


```python
print('연료가격 변수 추가(price_fl) - ')
print('c : 가스 2.35 , d : 디젤 2.38 , e : 에탄올 2.11 , p : 고급휘발유 2.76, r : 보통휘발유 2.22')

price_fl = pd.DataFrame({'fl': ['c', 'd', 'e', 'p', 'r'],
                         'price_fl' : [2.35, 2.38, 2.11, 2.76, 2.22]})
price_fl

merge_mpg_frm = pd.merge(mpg_frm, price_fl, how= 'inner', on = 'fl')
merge_mpg_frm
```

    연료가격 변수 추가(price_fl) - 
    c : 가스 2.35 , d : 디젤 2.38 , e : 에탄올 2.11 , p : 고급휘발유 2.76, r : 보통휘발유 2.22
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>manufacturer</th>
      <th>model</th>
      <th>displ</th>
      <th>year</th>
      <th>cyl</th>
      <th>trans</th>
      <th>drv</th>
      <th>cty</th>
      <th>hwy</th>
      <th>fl</th>
      <th>class</th>
      <th>price_fl_x</th>
      <th>price_fl_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>18</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>21</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>2</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>manual(m6)</td>
      <td>f</td>
      <td>20</td>
      <td>31</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>auto(av)</td>
      <td>f</td>
      <td>21</td>
      <td>30</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.8</td>
      <td>1999</td>
      <td>6</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>16</td>
      <td>26</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>229</th>
      <td>jeep</td>
      <td>grand cherokee 4wd</td>
      <td>3.0</td>
      <td>2008</td>
      <td>6</td>
      <td>auto(l5)</td>
      <td>4</td>
      <td>17</td>
      <td>22</td>
      <td>d</td>
      <td>suv</td>
      <td>2.38</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>230</th>
      <td>volkswagen</td>
      <td>jetta</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>33</td>
      <td>44</td>
      <td>d</td>
      <td>compact</td>
      <td>2.38</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>231</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>35</td>
      <td>44</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>232</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l4)</td>
      <td>f</td>
      <td>29</td>
      <td>41</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>233</th>
      <td>honda</td>
      <td>civic</td>
      <td>1.8</td>
      <td>2008</td>
      <td>4</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>24</td>
      <td>36</td>
      <td>c</td>
      <td>subcompact</td>
      <td>2.35</td>
      <td>2.35</td>
    </tr>
  </tbody>
</table>
<p>234 rows × 13 columns</p>
</div>




```python
# 데이터 전처리 과정에서 결측값 확인하기
merge_mpg_frm.isna().sum()
```




    manufacturer    0
    model           0
    displ           0
    year            0
    cyl             0
    trans           0
    drv             0
    cty             0
    hwy             0
    fl              0
    class           0
    price_fl_x      0
    price_fl_y      0
    dtype: int64




```python
# 구동방식(drv) 별 고속도로 연비(hwy)평균
# 임의적으로 결측값 처리를 위해서 더미 값을 넣어보도록 하자

for idx in range(0,234,7):
    merge_mpg_frm.loc[idx, 'hwy'] = np.NaN
```


```python
merge_mpg_frm.isna().sum()
```




    manufacturer     0
    model            0
    displ            0
    year             0
    cyl              0
    trans            0
    drv              0
    cty              0
    hwy             34
    fl               0
    class            0
    price_fl_x       0
    price_fl_y       0
    dtype: int64




```python
merge_mpg_frm[['drv', 'hwy']].isna().sum()
```




    drv     0
    hwy    34
    dtype: int64




```python
# hwy변수의 결측값을 제외하고, 어떤 구동방식의 고속도로평균 연비가 높은지 알아보자
# dropna()

drop_merge_mpg_frm = merge_mpg_frm[['drv', 'hwy']].dropna()
drop_merge_mpg_frm[['drv', 'hwy']].isna().sum()
drop_merge_mpg_frm.groupby('drv').mean().sort_values(by='hwy', ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hwy</th>
    </tr>
    <tr>
      <th>drv</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>f</th>
      <td>27.921348</td>
    </tr>
    <tr>
      <th>r</th>
      <td>20.772727</td>
    </tr>
    <tr>
      <th>4</th>
      <td>19.235955</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 구동방식별 연비평균을 비교하기 위한 막대 그래프로 시각화 해 보자
mean_frm = drop_merge_mpg_frm.groupby('drv').mean().sort_values(by='hwy', ascending=False)
X = mean_frm.index.values
Y = mean_frm.values.reshape(-1,)


plt.figure(figsize = (15,5))
plt.bar(np.arange(len(X)), Y, color = 'gray')
plt.title('구동방식별 연비평균')
plt.xlabel('구동방식')
plt.ylabel('연비평균')
plt.xticks(np.arange(len(X)), X)
plt.legend(loc = 'best', labels = ['구동방식별 연비평균'])

plt.show()
plt.close()
```


    
![png](output_25_0.png)
    



```python
mean_frm.plot(kind='bar', figsize=(15,5))
plt.show()
plt.close()
```


    
![png](output_26_0.png)
    



```python
# 위에서 했던 방식과 동일하게 구동방식별 고속도로, 도시연비의 평균을 구해보고
# 이를 데이터 프레임으로 만들어서 막대바로 시각화 해 보자
# hwy변수의 결측값을 제외하고, 어떤 구동방식의 고속도로평균 연비가 높은지 알아보자
drop2_merge_mpg_frm = merge_mpg_frm[['drv','hwy', 'cty']].dropna()

print(merge_mpg_frm.isna().sum())

drop2_merge_bar = drop2_merge_mpg_frm.groupby('drv').mean()
```

    manufacturer     0
    model            0
    displ            0
    year             0
    cyl              0
    trans            0
    drv              0
    cty              0
    hwy             34
    fl               0
    class            0
    price_fl_x       0
    price_fl_y       0
    dtype: int64
    


```python
drop2_merge_bar
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hwy</th>
      <th>cty</th>
    </tr>
    <tr>
      <th>drv</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>19.235955</td>
      <td>14.393258</td>
    </tr>
    <tr>
      <th>f</th>
      <td>27.921348</td>
      <td>19.786517</td>
    </tr>
    <tr>
      <th>r</th>
      <td>20.772727</td>
      <td>13.954545</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = drop2_merge_bar.index.values
Y = drop2_merge_bar['hwy'].values.reshape(-1,)
Z = drop2_merge_bar['cty'].values.reshape(-1,)

print(X, type(X))
print(Y, type(Y))
```

    [4 'f' 'r'] <class 'numpy.ndarray'>
    [19.23595506 27.92134831 20.77272727] <class 'numpy.ndarray'>
    


```python
drop2_merge_bar.plot(kind='bar', figsize=(15,5))
plt.grid()
plt.show()
plt.close()
```


    
![png](output_30_0.png)
    



```python
# 자동차(class)중에서 어떤 자동차가 가장 많은지 알아보려고 한다.
# 종류별 빈도를 막대바로 시각화 해 보자(나중에)

# 값의 종류별 빈도수 검사

values_cnt_series = mpg_frm['class'].value_counts()
values_cnt_series
```




    suv           62
    compact       47
    midsize       41
    subcompact    35
    pickup        33
    minivan       11
    2seater        5
    Name: class, dtype: int64




```python
values_cnt_series.plot(kind = 'bar', rot = 0)

plt.show()
plt.close()
```


    
![png](output_32_0.png)
    



```python
# 어떤 회사에서 생산한 suv 차종의 도시 연비가 높은지를 알아보려고 한다
# suv 차종을 대상으로 평균 도시연비가 가장 높은 회사 다섯곳을 막대 바로 시각화 해 보자(나중에)
# cty 컬럼을 기준으로 역순정렬
# 정렬결과에 대한 상위 5건 추출

manu_subset = mpg_frm[['manufacturer', 'class', 'cty']]
suv_manu_mpg = manu_subset[manu_subset['class'] =='suv']
mf_suv_cty = suv_manu_mpg.groupby('manufacturer').mean()
bar03_mpg = mf_suv_cty['cty'].sort_values(ascending = False).head(5)
bar03_mpg
```




    manufacturer
    subaru     18.833333
    toyota     14.375000
    nissan     13.750000
    jeep       13.500000
    mercury    13.250000
    Name: cty, dtype: float64




```python
mpg_frm.rename({'class':'grade'}, axis=1, inplace = True)
suv_mpg_frm = mpg_frm.query("grade == 'suv'")[['manufacturer', 'cty']].groupby('manufacturer').mean()
```


```python
suv_mpg_frm.sort_values(by='cty', ascending = False).head(5).plot(kind='bar', rot=0)
```




    <AxesSubplot:xlabel='manufacturer'>




    
![png](output_35_1.png)
    


- pie plot
- 카테고리별 값의 상대적 비교를 해야할 경우


```python
labels = ['라면', '샐러드', '샌드위치', '잡채', '생고기']
sizes = [15,15,20,25,25]
colors = ['gold', 'blue', 'red', 'yellow', 'green']

plt.figure(figsize=(5,5))
plt.pie(sizes, labels = labels, colors = colors, shadow = True, autopct='%1.1f%%')
plt.title('Pie Chart')
plt.axis('equal')

plt.show()
plt.close()
```


    
![png](output_37_0.png)
    



```python
# 데이터의 개수 카운트를 위해서 1을 가진 열(cnt)을 추가
# 제조국가 값을 나라명 변경 1: 미국, 2: 대한민국, 3:중국
# 제조국에 대한 파이 차트 그리기 - cnt
# 범례
auto_mpg_frm['origin'].unique()
```




    array([1, 3, 2], dtype=int64)




```python
auto_mpg_frm['cnt'] = 1
```


```python
manu_pie = auto_mpg_frm.groupby('origin').sum()['cnt']
```


```python
plt.figure(figsize=(7,5))
plt.pie(manu_pie.values, labels = ['미국','대한민국','중국'],
        startangle = 90, autopct='%1.1f%%')

plt.title('Pie Chart', size = 20, weight = 'bold', color= 'blue')
plt.legend(loc = 'best')
plt.axis('equal')

plt.show()
plt.close()
```


    
![png](output_41_0.png)
    


- hist plot: 구간에 대한 데이터 집계


```python
# 연비(mpg) 열에 대한 히스토그램을 시각화
auto_mpg_frm['mpg']

plt.figure(figsize = (7,5))
plt.hist(auto_mpg_frm['mpg'], bins = 30)

plt.title('Hist Chart', size = 20, weight = 'bold', color = 'blue')
plt.grid()
plt.show()
plt.close()
```


    
![png](output_43_0.png)
    



```python
mpg_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>manufacturer</th>
      <th>model</th>
      <th>displ</th>
      <th>year</th>
      <th>cyl</th>
      <th>trans</th>
      <th>drv</th>
      <th>cty</th>
      <th>hwy</th>
      <th>fl</th>
      <th>grade</th>
      <th>price_fl</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>18</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>2</th>
      <td>audi</td>
      <td>a4</td>
      <td>1.8</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>21</td>
      <td>29</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>3</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>manual(m6)</td>
      <td>f</td>
      <td>20</td>
      <td>31</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>4</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.0</td>
      <td>2008</td>
      <td>4</td>
      <td>auto(av)</td>
      <td>f</td>
      <td>21</td>
      <td>30</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
    </tr>
    <tr>
      <th>5</th>
      <td>audi</td>
      <td>a4</td>
      <td>2.8</td>
      <td>1999</td>
      <td>6</td>
      <td>auto(l5)</td>
      <td>f</td>
      <td>16</td>
      <td>26</td>
      <td>p</td>
      <td>compact</td>
      <td>2.76</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 이상치 정제
# car_mpg 데이터에서 구동방식별 고속도로 연비 평균과 도시연비 평균을 극단치를 제외하고 확인
# 각 연비별 이상치 확인 boxplot()
outlier_frm = mpg_frm[['hwy', 'cty']]
outlier_frm.boxplot()
```




    <AxesSubplot:>




    
![png](output_45_1.png)
    



```python
# 사분위 정보 - quantile()
print('3사분위 - \n', outlier_frm.quantile(q=0.75))
print('1사분위 - \n', outlier_frm.quantile(q=0.25))
```

    3사분위 - 
     hwy    27.0
    cty    19.0
    Name: 0.75, dtype: float64
    1사분위 - 
     hwy    18.0
    cty    14.0
    Name: 0.25, dtype: float64
    


```python
# IQR (3사분위 수 - 1사분위 수)
iqr = outlier_frm.quantile(q=0.75) - outlier_frm.quantile(q=0.25)
iqr
```




    hwy    9.0
    cty    5.0
    dtype: float64




```python
lower = outlier_frm.quantile(q=0.25) - 1.5 * iqr
lower
```




    hwy    4.5
    cty    6.5
    dtype: float64




```python
upper = outlier_frm.quantile(q=0.75) + 1.5 * iqr
upper
```




    hwy    40.5
    cty    26.5
    dtype: float64




```python
# 도시 연비의 이상치 데이터 추출

print(outlier_frm['hwy'][outlier_frm['hwy'] > upper['hwy']])
print(outlier_frm['cty'][outlier_frm['cty'] > upper['cty']])
display(mpg_frm.query('hwy > ' + str(upper['hwy'])))
display(mpg_frm.query('cty > ' + str(upper['cty'])))

```

    213    44
    222    44
    223    41
    Name: hwy, dtype: int64
    100    28
    197    28
    213    33
    222    35
    223    29
    Name: cty, dtype: int64
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>manufacturer</th>
      <th>model</th>
      <th>displ</th>
      <th>year</th>
      <th>cyl</th>
      <th>trans</th>
      <th>drv</th>
      <th>cty</th>
      <th>hwy</th>
      <th>fl</th>
      <th>grade</th>
      <th>price_fl</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>213</th>
      <td>volkswagen</td>
      <td>jetta</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>33</td>
      <td>44</td>
      <td>d</td>
      <td>compact</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>222</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>35</td>
      <td>44</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>223</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l4)</td>
      <td>f</td>
      <td>29</td>
      <td>41</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>manufacturer</th>
      <th>model</th>
      <th>displ</th>
      <th>year</th>
      <th>cyl</th>
      <th>trans</th>
      <th>drv</th>
      <th>cty</th>
      <th>hwy</th>
      <th>fl</th>
      <th>grade</th>
      <th>price_fl</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>100</th>
      <td>honda</td>
      <td>civic</td>
      <td>1.6</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>28</td>
      <td>33</td>
      <td>r</td>
      <td>subcompact</td>
      <td>2.22</td>
    </tr>
    <tr>
      <th>197</th>
      <td>toyota</td>
      <td>corolla</td>
      <td>1.8</td>
      <td>2008</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>28</td>
      <td>37</td>
      <td>r</td>
      <td>compact</td>
      <td>2.22</td>
    </tr>
    <tr>
      <th>213</th>
      <td>volkswagen</td>
      <td>jetta</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>33</td>
      <td>44</td>
      <td>d</td>
      <td>compact</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>222</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>manual(m5)</td>
      <td>f</td>
      <td>35</td>
      <td>44</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
    </tr>
    <tr>
      <th>223</th>
      <td>volkswagen</td>
      <td>new beetle</td>
      <td>1.9</td>
      <td>1999</td>
      <td>4</td>
      <td>auto(l4)</td>
      <td>f</td>
      <td>29</td>
      <td>41</td>
      <td>d</td>
      <td>subcompact</td>
      <td>2.38</td>
    </tr>
  </tbody>
</table>
</div>



```python
# hwy 연비에 대한 이상치를 결측값으로 변경
# 결측값 있는지 확인

hwy_outlier_frm = mpg_frm.query('hwy > ' + str(upper['hwy']))
cty_outlier_frm = mpg_frm.query('cty > ' + str(upper['cty']))

result_frm = mpg_frm.copy()

for idx in hwy_outlier_frm.index :
    result_frm.loc[idx, 'hwy'] = np.NaN
    
result_frm.isnull().sum()
```




    manufacturer    0
    model           0
    displ           0
    year            0
    cyl             0
    trans           0
    drv             0
    cty             0
    hwy             3
    fl              0
    grade           0
    price_fl        0
    dtype: int64




```python
# cty 연비에 대한 이상치를 결측값으로 변경
# 결측값 있는지 확인

for idx in cty_outlier_frm.index :
    result_frm.loc[idx, 'cty'] = np.NaN
    
result_frm.isnull().sum()
```




    manufacturer    0
    model           0
    displ           0
    year            0
    cyl             0
    trans           0
    drv             0
    cty             5
    hwy             3
    fl              0
    grade           0
    price_fl        0
    dtype: int64




```python
# 결측값 제거한 구동방식별 고속도로, 도시 연비 평균 시각화로 비교

result_frm.dropna(inplace=True)
total_drv_frm = result_frm.groupby('drv')[['cty', 'hwy']].mean()
total_drv_frm.plot(kind = 'bar', rot = 0)

plt.title('구동방식별 평균')
plt.xlabel('구동방식')
plt.ylabel('연비평균')
plt.legend(loc = 'best')

plt.show()
plt.close()
```


    
![png](output_53_0.png)
    



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
