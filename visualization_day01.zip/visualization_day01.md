#### 학습목표
- 시각화 패키지 matplotlib
- 서브 패키지   pyplot
- 고급 시각화   seaborn
- 지도 시각화   folium
- 현업(BI)      Tableau


```python
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt

%matplotlib inline
```


```python
# 한글 폰트 문제 해결
import platform
from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~')

```


```python
# 워닝 메시지 무시
import warnings
warnings.filterwarnings(action='ignore')
```


```python
# 차트 축 <- 음수 부호 지원
import matplotlib
matplotlib.rcParams['axes.unicode_minus'] = False
```

Plot 유형
- line : 데이터가 시간, 순서 등에 따라서 어떻게 변화하는지를 보여주는 시각화
- area
- surface
- bar
- hist
- box etc...


```python
# 그림판 준비
plt.figure()
plt.title('라인 플롯')

plt.plot([1,2,3,4,5,6,7,8,9])
plt.plot([1,4,9,4,5,6,7,8,16])
plt.plot([1,10,9,4,8,6,7,10,16])

plt.show()
plt.close
```


    
![png](output_6_0.png)
    





    <function matplotlib.pyplot.close(fig=None)>




```python
plt.figure()
plt.title('라인 플롯')

plt.plot([10, 30, 60, 95], [1,4,9,16],
        c = 'red',
        lw = 5,
        ls = '--',
        marker = 'o',
        ms = 15,
        mec = 'g',
        mew = 5,
        mfc = 'blue')

plt.xlabel('x축')
plt.ylabel('y축')

plt.show()
plt.close
```


    
![png](output_7_0.png)
    





    <function matplotlib.pyplot.close(fig=None)>



- 시도별 전출입 인구수.xlsx 이용한 라인플롯


```python
tmp_frm = pd.read_excel('./data/visualization_data/시도별 전출입 인구수.xlsx' ,
                       header = 0)
tmp_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>전출지별</th>
      <th>전입지별</th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>전출지별</td>
      <td>전입지별</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>...</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>전국</td>
      <td>전국</td>
      <td>4046536.0</td>
      <td>4210164.0</td>
      <td>3687938.0</td>
      <td>4860418.0</td>
      <td>5297969.0</td>
      <td>9011440.0</td>
      <td>6773250.0</td>
      <td>7397623.0</td>
      <td>...</td>
      <td>8808256.0</td>
      <td>8487275.0</td>
      <td>8226594.0</td>
      <td>8127195.0</td>
      <td>7506691.0</td>
      <td>7411784.0</td>
      <td>7629098.0</td>
      <td>7755286.0</td>
      <td>7378430.0</td>
      <td>7154226.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>서울특별시</td>
      <td>1742813.0</td>
      <td>1671705.0</td>
      <td>1349333.0</td>
      <td>1831858.0</td>
      <td>2050392.0</td>
      <td>3396662.0</td>
      <td>2756510.0</td>
      <td>2893403.0</td>
      <td>...</td>
      <td>2025358.0</td>
      <td>1873188.0</td>
      <td>1733015.0</td>
      <td>1721748.0</td>
      <td>1555281.0</td>
      <td>1520090.0</td>
      <td>1573594.0</td>
      <td>1589431.0</td>
      <td>1515602.0</td>
      <td>1472937.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>부산광역시</td>
      <td>448577.0</td>
      <td>389797.0</td>
      <td>362202.0</td>
      <td>482061.0</td>
      <td>680984.0</td>
      <td>805979.0</td>
      <td>724664.0</td>
      <td>785117.0</td>
      <td>...</td>
      <td>514502.0</td>
      <td>519310.0</td>
      <td>519334.0</td>
      <td>508043.0</td>
      <td>461042.0</td>
      <td>478451.0</td>
      <td>485710.0</td>
      <td>507031.0</td>
      <td>459015.0</td>
      <td>439073.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>대구광역시</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>409938.0</td>
      <td>398626.0</td>
      <td>370817.0</td>
      <td>370563.0</td>
      <td>348642.0</td>
      <td>351873.0</td>
      <td>350213.0</td>
      <td>351424.0</td>
      <td>328228.0</td>
      <td>321182.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 50 columns</p>
</div>




```python
tmp_frm = tmp_frm.fillna(method = 'ffill')
tmp_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>전출지별</th>
      <th>전입지별</th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>전출지별</td>
      <td>전입지별</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>...</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
      <td>이동자수 (명)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>전국</td>
      <td>전국</td>
      <td>4046536.0</td>
      <td>4210164.0</td>
      <td>3687938.0</td>
      <td>4860418.0</td>
      <td>5297969.0</td>
      <td>9011440.0</td>
      <td>6773250.0</td>
      <td>7397623.0</td>
      <td>...</td>
      <td>8808256.0</td>
      <td>8487275.0</td>
      <td>8226594.0</td>
      <td>8127195.0</td>
      <td>7506691.0</td>
      <td>7411784.0</td>
      <td>7629098.0</td>
      <td>7755286.0</td>
      <td>7378430.0</td>
      <td>7154226.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>전국</td>
      <td>서울특별시</td>
      <td>1742813.0</td>
      <td>1671705.0</td>
      <td>1349333.0</td>
      <td>1831858.0</td>
      <td>2050392.0</td>
      <td>3396662.0</td>
      <td>2756510.0</td>
      <td>2893403.0</td>
      <td>...</td>
      <td>2025358.0</td>
      <td>1873188.0</td>
      <td>1733015.0</td>
      <td>1721748.0</td>
      <td>1555281.0</td>
      <td>1520090.0</td>
      <td>1573594.0</td>
      <td>1589431.0</td>
      <td>1515602.0</td>
      <td>1472937.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>전국</td>
      <td>부산광역시</td>
      <td>448577.0</td>
      <td>389797.0</td>
      <td>362202.0</td>
      <td>482061.0</td>
      <td>680984.0</td>
      <td>805979.0</td>
      <td>724664.0</td>
      <td>785117.0</td>
      <td>...</td>
      <td>514502.0</td>
      <td>519310.0</td>
      <td>519334.0</td>
      <td>508043.0</td>
      <td>461042.0</td>
      <td>478451.0</td>
      <td>485710.0</td>
      <td>507031.0</td>
      <td>459015.0</td>
      <td>439073.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>전국</td>
      <td>대구광역시</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>409938.0</td>
      <td>398626.0</td>
      <td>370817.0</td>
      <td>370563.0</td>
      <td>348642.0</td>
      <td>351873.0</td>
      <td>350213.0</td>
      <td>351424.0</td>
      <td>328228.0</td>
      <td>321182.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 50 columns</p>
</div>




```python
# 서울에서 다른 지역으로 이동한 데이터만 추출하여 서브셋 만들기
seoul_frm = tmp_frm[(tmp_frm['전출지별'] == '서울특별시') & (tmp_frm['전입지별'] != '서울특별시')]
```


```python
seoul_frm.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 17 entries, 19 to 36
    Data columns (total 50 columns):
     #   Column  Non-Null Count  Dtype 
    ---  ------  --------------  ----- 
     0   전출지별    17 non-null     object
     1   전입지별    17 non-null     object
     2   1970    17 non-null     object
     3   1971    17 non-null     object
     4   1972    17 non-null     object
     5   1973    17 non-null     object
     6   1974    17 non-null     object
     7   1975    17 non-null     object
     8   1976    17 non-null     object
     9   1977    17 non-null     object
     10  1978    17 non-null     object
     11  1979    17 non-null     object
     12  1980    17 non-null     object
     13  1981    17 non-null     object
     14  1982    17 non-null     object
     15  1983    17 non-null     object
     16  1984    17 non-null     object
     17  1985    17 non-null     object
     18  1986    17 non-null     object
     19  1987    17 non-null     object
     20  1988    17 non-null     object
     21  1989    17 non-null     object
     22  1990    17 non-null     object
     23  1991    17 non-null     object
     24  1992    17 non-null     object
     25  1993    17 non-null     object
     26  1994    17 non-null     object
     27  1995    17 non-null     object
     28  1996    17 non-null     object
     29  1997    17 non-null     object
     30  1998    17 non-null     object
     31  1999    17 non-null     object
     32  2000    17 non-null     object
     33  2001    17 non-null     object
     34  2002    17 non-null     object
     35  2003    17 non-null     object
     36  2004    17 non-null     object
     37  2005    17 non-null     object
     38  2006    17 non-null     object
     39  2007    17 non-null     object
     40  2008    17 non-null     object
     41  2009    17 non-null     object
     42  2010    17 non-null     object
     43  2011    17 non-null     object
     44  2012    17 non-null     object
     45  2013    17 non-null     object
     46  2014    17 non-null     object
     47  2015    17 non-null     object
     48  2016    17 non-null     object
     49  2017    17 non-null     object
    dtypes: object(50)
    memory usage: 6.8+ KB
    


```python
# 전출지별 컬럼 삭제 - drop
seoul_frm.drop('전출지별', inplace = True, axis = 1)
```


```python
# 전입지별 -> 전입지 변경
seoul_frm.rename(columns = {'전입지별': '전입지'},
                inplace = True)
```


```python
seoul_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>전입지</th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>1978</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>19</th>
      <td>전국</td>
      <td>1448985.0</td>
      <td>1419016.0</td>
      <td>1210559.0</td>
      <td>1647268.0</td>
      <td>1819660.0</td>
      <td>2937093.0</td>
      <td>2495620.0</td>
      <td>2678007.0</td>
      <td>3028911.0</td>
      <td>...</td>
      <td>2083352.0</td>
      <td>1925452.0</td>
      <td>1848038.0</td>
      <td>1834806.0</td>
      <td>1658928.0</td>
      <td>1620640.0</td>
      <td>1661425.0</td>
      <td>1726687.0</td>
      <td>1655859.0</td>
      <td>1571423.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>부산광역시</td>
      <td>11568.0</td>
      <td>11130.0</td>
      <td>11768.0</td>
      <td>16307.0</td>
      <td>22220.0</td>
      <td>27515.0</td>
      <td>23732.0</td>
      <td>27213.0</td>
      <td>29856.0</td>
      <td>...</td>
      <td>17353.0</td>
      <td>17738.0</td>
      <td>17418.0</td>
      <td>18816.0</td>
      <td>16135.0</td>
      <td>16153.0</td>
      <td>17320.0</td>
      <td>17009.0</td>
      <td>15062.0</td>
      <td>14484.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>대구광역시</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>9720.0</td>
      <td>10464.0</td>
      <td>10277.0</td>
      <td>10397.0</td>
      <td>10135.0</td>
      <td>10631.0</td>
      <td>10062.0</td>
      <td>10191.0</td>
      <td>9623.0</td>
      <td>8891.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>인천광역시</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>50493.0</td>
      <td>45392.0</td>
      <td>46082.0</td>
      <td>51641.0</td>
      <td>49640.0</td>
      <td>47424.0</td>
      <td>43212.0</td>
      <td>44915.0</td>
      <td>43745.0</td>
      <td>40485.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>광주광역시</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>10846.0</td>
      <td>11725.0</td>
      <td>11095.0</td>
      <td>10587.0</td>
      <td>10154.0</td>
      <td>9129.0</td>
      <td>9759.0</td>
      <td>9216.0</td>
      <td>8354.0</td>
      <td>7932.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 49 columns</p>
</div>




```python
seoul_frm.set_index('전입지', inplace=True)
seoul_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1970</th>
      <th>1971</th>
      <th>1972</th>
      <th>1973</th>
      <th>1974</th>
      <th>1975</th>
      <th>1976</th>
      <th>1977</th>
      <th>1978</th>
      <th>1979</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>전입지</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>전국</th>
      <td>1448985.0</td>
      <td>1419016.0</td>
      <td>1210559.0</td>
      <td>1647268.0</td>
      <td>1819660.0</td>
      <td>2937093.0</td>
      <td>2495620.0</td>
      <td>2678007.0</td>
      <td>3028911.0</td>
      <td>2441242.0</td>
      <td>...</td>
      <td>2083352.0</td>
      <td>1925452.0</td>
      <td>1848038.0</td>
      <td>1834806.0</td>
      <td>1658928.0</td>
      <td>1620640.0</td>
      <td>1661425.0</td>
      <td>1726687.0</td>
      <td>1655859.0</td>
      <td>1571423.0</td>
    </tr>
    <tr>
      <th>부산광역시</th>
      <td>11568.0</td>
      <td>11130.0</td>
      <td>11768.0</td>
      <td>16307.0</td>
      <td>22220.0</td>
      <td>27515.0</td>
      <td>23732.0</td>
      <td>27213.0</td>
      <td>29856.0</td>
      <td>28542.0</td>
      <td>...</td>
      <td>17353.0</td>
      <td>17738.0</td>
      <td>17418.0</td>
      <td>18816.0</td>
      <td>16135.0</td>
      <td>16153.0</td>
      <td>17320.0</td>
      <td>17009.0</td>
      <td>15062.0</td>
      <td>14484.0</td>
    </tr>
    <tr>
      <th>대구광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>9720.0</td>
      <td>10464.0</td>
      <td>10277.0</td>
      <td>10397.0</td>
      <td>10135.0</td>
      <td>10631.0</td>
      <td>10062.0</td>
      <td>10191.0</td>
      <td>9623.0</td>
      <td>8891.0</td>
    </tr>
    <tr>
      <th>인천광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>50493.0</td>
      <td>45392.0</td>
      <td>46082.0</td>
      <td>51641.0</td>
      <td>49640.0</td>
      <td>47424.0</td>
      <td>43212.0</td>
      <td>44915.0</td>
      <td>43745.0</td>
      <td>40485.0</td>
    </tr>
    <tr>
      <th>광주광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>10846.0</td>
      <td>11725.0</td>
      <td>11095.0</td>
      <td>10587.0</td>
      <td>10154.0</td>
      <td>9129.0</td>
      <td>9759.0</td>
      <td>9216.0</td>
      <td>8354.0</td>
      <td>7932.0</td>
    </tr>
    <tr>
      <th>대전광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>13515.0</td>
      <td>13632.0</td>
      <td>13819.0</td>
      <td>13900.0</td>
      <td>14080.0</td>
      <td>13440.0</td>
      <td>13403.0</td>
      <td>13453.0</td>
      <td>12619.0</td>
      <td>11815.0</td>
    </tr>
    <tr>
      <th>울산광역시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>5057.0</td>
      <td>4845.0</td>
      <td>4742.0</td>
      <td>5188.0</td>
      <td>5691.0</td>
      <td>5542.0</td>
      <td>6047.0</td>
      <td>5950.0</td>
      <td>5102.0</td>
      <td>4260.0</td>
    </tr>
    <tr>
      <th>세종특별자치시</th>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>2998.0</td>
      <td>2851.0</td>
      <td>6481.0</td>
      <td>7550.0</td>
      <td>5943.0</td>
      <td>5813.0</td>
    </tr>
    <tr>
      <th>경기도</th>
      <td>130149.0</td>
      <td>150313.0</td>
      <td>93333.0</td>
      <td>143234.0</td>
      <td>149045.0</td>
      <td>253705.0</td>
      <td>202276.0</td>
      <td>207722.0</td>
      <td>237684.0</td>
      <td>278411.0</td>
      <td>...</td>
      <td>412408.0</td>
      <td>398282.0</td>
      <td>410735.0</td>
      <td>373771.0</td>
      <td>354135.0</td>
      <td>340801.0</td>
      <td>332785.0</td>
      <td>359337.0</td>
      <td>370760.0</td>
      <td>342433.0</td>
    </tr>
    <tr>
      <th>강원도</th>
      <td>9352.0</td>
      <td>12885.0</td>
      <td>13561.0</td>
      <td>16481.0</td>
      <td>15479.0</td>
      <td>27837.0</td>
      <td>25927.0</td>
      <td>25415.0</td>
      <td>26700.0</td>
      <td>27599.0</td>
      <td>...</td>
      <td>23668.0</td>
      <td>23331.0</td>
      <td>22736.0</td>
      <td>23624.0</td>
      <td>22332.0</td>
      <td>20601.0</td>
      <td>21173.0</td>
      <td>22659.0</td>
      <td>21590.0</td>
      <td>21016.0</td>
    </tr>
    <tr>
      <th>충청북도</th>
      <td>6700.0</td>
      <td>9457.0</td>
      <td>10853.0</td>
      <td>12617.0</td>
      <td>11786.0</td>
      <td>21073.0</td>
      <td>18029.0</td>
      <td>17478.0</td>
      <td>18420.0</td>
      <td>20047.0</td>
      <td>...</td>
      <td>15294.0</td>
      <td>15295.0</td>
      <td>15461.0</td>
      <td>15318.0</td>
      <td>14555.0</td>
      <td>13783.0</td>
      <td>14244.0</td>
      <td>14379.0</td>
      <td>14087.0</td>
      <td>13302.0</td>
    </tr>
    <tr>
      <th>충청남도</th>
      <td>15954.0</td>
      <td>18943.0</td>
      <td>23406.0</td>
      <td>27139.0</td>
      <td>25509.0</td>
      <td>51205.0</td>
      <td>41447.0</td>
      <td>43993.0</td>
      <td>48091.0</td>
      <td>45388.0</td>
      <td>...</td>
      <td>27458.0</td>
      <td>24889.0</td>
      <td>24522.0</td>
      <td>24723.0</td>
      <td>22269.0</td>
      <td>21486.0</td>
      <td>21473.0</td>
      <td>22299.0</td>
      <td>21741.0</td>
      <td>21020.0</td>
    </tr>
    <tr>
      <th>전라북도</th>
      <td>10814.0</td>
      <td>13192.0</td>
      <td>16583.0</td>
      <td>18642.0</td>
      <td>16647.0</td>
      <td>34411.0</td>
      <td>29835.0</td>
      <td>28444.0</td>
      <td>29676.0</td>
      <td>31570.0</td>
      <td>...</td>
      <td>18390.0</td>
      <td>18332.0</td>
      <td>17569.0</td>
      <td>17755.0</td>
      <td>16120.0</td>
      <td>14909.0</td>
      <td>14566.0</td>
      <td>14835.0</td>
      <td>13835.0</td>
      <td>13179.0</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>10513.0</td>
      <td>16755.0</td>
      <td>20157.0</td>
      <td>22160.0</td>
      <td>21314.0</td>
      <td>46610.0</td>
      <td>46251.0</td>
      <td>43430.0</td>
      <td>44624.0</td>
      <td>47934.0</td>
      <td>...</td>
      <td>16601.0</td>
      <td>17468.0</td>
      <td>16429.0</td>
      <td>15974.0</td>
      <td>14765.0</td>
      <td>14187.0</td>
      <td>14591.0</td>
      <td>14598.0</td>
      <td>13065.0</td>
      <td>12426.0</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>11868.0</td>
      <td>16459.0</td>
      <td>22073.0</td>
      <td>27531.0</td>
      <td>26902.0</td>
      <td>46177.0</td>
      <td>40376.0</td>
      <td>41155.0</td>
      <td>42940.0</td>
      <td>43565.0</td>
      <td>...</td>
      <td>15425.0</td>
      <td>16569.0</td>
      <td>16042.0</td>
      <td>15818.0</td>
      <td>15191.0</td>
      <td>14420.0</td>
      <td>14456.0</td>
      <td>15113.0</td>
      <td>14236.0</td>
      <td>12464.0</td>
    </tr>
    <tr>
      <th>경상남도</th>
      <td>8409.0</td>
      <td>10001.0</td>
      <td>11263.0</td>
      <td>15193.0</td>
      <td>16771.0</td>
      <td>23150.0</td>
      <td>22400.0</td>
      <td>27393.0</td>
      <td>28697.0</td>
      <td>30183.0</td>
      <td>...</td>
      <td>15438.0</td>
      <td>15303.0</td>
      <td>15689.0</td>
      <td>16039.0</td>
      <td>14474.0</td>
      <td>14447.0</td>
      <td>14799.0</td>
      <td>15220.0</td>
      <td>13717.0</td>
      <td>12692.0</td>
    </tr>
    <tr>
      <th>제주특별자치도</th>
      <td>1039.0</td>
      <td>1325.0</td>
      <td>1617.0</td>
      <td>2456.0</td>
      <td>2261.0</td>
      <td>3440.0</td>
      <td>3623.0</td>
      <td>3551.0</td>
      <td>3937.0</td>
      <td>4261.0</td>
      <td>...</td>
      <td>5473.0</td>
      <td>5332.0</td>
      <td>5714.0</td>
      <td>6133.0</td>
      <td>6954.0</td>
      <td>7828.0</td>
      <td>9031.0</td>
      <td>10434.0</td>
      <td>10465.0</td>
      <td>10404.0</td>
    </tr>
  </tbody>
</table>
<p>17 rows × 48 columns</p>
</div>




```python
# 경기도 전입인구 데이터만 추출
data_series = seoul_frm.loc['경기도']

print('type - ', type(data_series))
print()
print('index - ', data_series.index)
print()
print('values - ', data_series.values)
print('values type - ', type(data_series.values))
```

    type -  <class 'pandas.core.series.Series'>
    
    index -  Index(['1970', '1971', '1972', '1973', '1974', '1975', '1976', '1977', '1978',
           '1979', '1980', '1981', '1982', '1983', '1984', '1985', '1986', '1987',
           '1988', '1989', '1990', '1991', '1992', '1993', '1994', '1995', '1996',
           '1997', '1998', '1999', '2000', '2001', '2002', '2003', '2004', '2005',
           '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014',
           '2015', '2016', '2017'],
          dtype='object')
    
    values -  [130149.0 150313.0 93333.0 143234.0 149045.0 253705.0 202276.0 207722.0
     237684.0 278411.0 297539.0 252073.0 320174.0 400875.0 352238.0 390265.0
     412535.0 405220.0 415174.0 412933.0 473889.0 384714.0 428344.0 502584.0
     542204.0 599411.0 520566.0 495454.0 407050.0 471841.0 435573.0 499575.0
     516765.0 457656.0 400206.0 414621.0 449632.0 431637.0 412408.0 398282.0
     410735.0 373771.0 354135.0 340801.0 332785.0 359337.0 370760.0 342433.0]
    values type -  <class 'numpy.ndarray'>
    


```python
# 경기도로 이동한 인구 데이터를 이용한 시각화
plt.figure(figsize = (15, 5))
plt.title('서울 -> 경기도')

plt.plot(data_series.index, data_series.values, 
         marker = '+',
         ms = 5)

plt.xlabel('연도')
plt.ylabel('이동 인구수')

plt.legend(labels=['서울 -> 경기도'], loc = 'best')
plt.ylim(5000, 700000)
plt.xticks(rotation = 75)

plt.show()
plt.close
```


    
![png](output_18_0.png)
    





    <function matplotlib.pyplot.close(fig=None)>




```python
# 충남, 경북, 전남으로 이동한 인구 데이터를 이용한 시각화
plt.figure(figsize = (15, 5))

plt.plot(seoul_frm.columns.values, seoul_frm.loc['충청남도'].values, label = '충청남도')
plt.plot(seoul_frm.columns.values, seoul_frm.loc['경상북도'].values, label = '경상북도')
plt.plot(seoul_frm.columns.values, seoul_frm.loc['전라남도'].values, label = '전라남도')

plt.xlabel('연도')
plt.ylabel('이동 인구수')

plt.xticks(rotation = 75)
plt.legend(loc = 'best')

plt.show()
plt.close
```


    
![png](output_19_0.png)
    





    <function matplotlib.pyplot.close(fig=None)>




```python
# subplot

fig = plt.figure(figsize = (20, 7))

area01 = fig.add_subplot(1,3,1)
area01.plot(seoul_frm.columns.values, seoul_frm.loc['충청남도'].values, label = '충청남도')
area01.set_title('충청남도')
area01.set_xlabel('연도')
area01.set_ylabel('이동 인구수')
area01.set_xticklabels(labels = seoul_frm.columns.values, rotaiton = 90)
area01.legend(loc='best')

area02 = fig.add_subplot(1,3,2)
area03 = fig.add_subplot(1,3,3)

area02.plot(seoul_frm.columns.values, seoul_frm.loc['경상북도'].values, label = '경상북도')
area03.plot(seoul_frm.columns.values, seoul_frm.loc['전라남도'].values, label = '전라남도')

plt.show()
plt.close()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Input In [67], in <cell line: 10>()
          8 area01.set_xlabel('연도')
          9 area01.set_ylabel('이동 인구수')
    ---> 10 area01.set_xticklabels(labels = seoul_frm.columns.values, rotaiton = 90)
         11 area01.legend(loc='best')
         13 area02 = fig.add_subplot(1,3,2)
    

    File ~\anaconda3\lib\site-packages\matplotlib\axes\_base.py:75, in _axis_method_wrapper.__set_name__.<locals>.wrapper(self, *args, **kwargs)
         74 def wrapper(self, *args, **kwargs):
    ---> 75     return get_method(self)(*args, **kwargs)
    

    File ~\anaconda3\lib\site-packages\matplotlib\axis.py:1798, in Axis._set_ticklabels(self, labels, fontdict, minor, **kwargs)
       1796 if fontdict is not None:
       1797     kwargs.update(fontdict)
    -> 1798 return self.set_ticklabels(labels, minor=minor, **kwargs)
    

    File ~\anaconda3\lib\site-packages\matplotlib\axis.py:1746, in Axis.set_ticklabels(self, ticklabels, minor, **kwargs)
       1744 # deal with label1
       1745 tick.label1.set_text(tick_label)
    -> 1746 tick.label1.update(kwargs)
       1747 # deal with label2
       1748 tick.label2.set_text(tick_label)
    

    File ~\anaconda3\lib\site-packages\matplotlib\text.py:172, in Text.update(self, kwargs)
        170 # Update bbox last, as it depends on font properties.
        171 bbox = kwargs.pop("bbox", sentinel)
    --> 172 super().update(kwargs)
        173 if bbox is not sentinel:
        174     self.set_bbox(bbox)
    

    File ~\anaconda3\lib\site-packages\matplotlib\artist.py:1064, in Artist.update(self, props)
       1062             func = getattr(self, f"set_{k}", None)
       1063             if not callable(func):
    -> 1064                 raise AttributeError(f"{type(self).__name__!r} object "
       1065                                      f"has no property {k!r}")
       1066             ret.append(func(v))
       1067 if ret:
    

    AttributeError: 'Text' object has no property 'rotaiton'



    
![png](output_20_1.png)
    



```python
import seaborn as sns

iris_frm = sns.load_dataset('iris')
titanic_frm = sns.load_dataset('titanic')
```

- barplot : x축이 범주형


```python
# 타이타닉 선실별 생존자 합 - groupby
titanic_frm.groupby('pclass').sum()['survived']

plt.figure(figsize = (15,5))
plt.bar(titanic_frm.groupby('pclass').sum()['survived'].index,
        titanic_frm.groupby('pclass').sum()['survived'].values,
        label = '생존자 수')

plt.legend(loc='best')
plt.xlabel('선실등급')
plt.ylabel('생존자 수')
plt.xticks(titanic_frm.groupby('pclass').sum()['survived'].index)

plt.show()
plt.close()
```


    
![png](output_23_0.png)
    



```python
titanic_frm.groupby('pclass').sum()['survived']

plt.figure(figsize = (15,5))
plt.barh(titanic_frm.groupby('pclass').sum()['survived'].index,
        titanic_frm.groupby('pclass').sum()['survived'].values,
        label = '생존자 수')

plt.legend(loc='best')
plt.xlabel('생존자 수')
plt.ylabel('선실등급')
plt.yticks(titanic_frm.groupby('pclass').sum()['survived'].index)

plt.show()
plt.close()
```


    
![png](output_24_0.png)
    



```python
# 서브셋 만들기
# 조건1) 충청남도, 경상북도, 강원도, 전라남도
# 조건2) 2010~2017


subset_frm = seoul_frm.loc[['충청남도','경상북도','강원도','전라남도'],'2010':'2017']
subset_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>전입지</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>충청남도</th>
      <td>24522.0</td>
      <td>24723.0</td>
      <td>22269.0</td>
      <td>21486.0</td>
      <td>21473.0</td>
      <td>22299.0</td>
      <td>21741.0</td>
      <td>21020.0</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>16042.0</td>
      <td>15818.0</td>
      <td>15191.0</td>
      <td>14420.0</td>
      <td>14456.0</td>
      <td>15113.0</td>
      <td>14236.0</td>
      <td>12464.0</td>
    </tr>
    <tr>
      <th>강원도</th>
      <td>22736.0</td>
      <td>23624.0</td>
      <td>22332.0</td>
      <td>20601.0</td>
      <td>21173.0</td>
      <td>22659.0</td>
      <td>21590.0</td>
      <td>21016.0</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>16429.0</td>
      <td>15974.0</td>
      <td>14765.0</td>
      <td>14187.0</td>
      <td>14591.0</td>
      <td>14598.0</td>
      <td>13065.0</td>
      <td>12426.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 연도에 따른 권역별 인구 전입 수 - bar 시각화
t_subset_frm = subset_frm.T
t_subset_frm.index
```




    Index(['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'], dtype='object')




```python


plt.figure()

t_subset_frm.plot(kind = 'bar',
                 figsize = (15,5))
plt.title('연도에 따른 권역별 인구 전입 수')
plt.xlabel('연도')
plt.ylabel('전입 인구 수')

plt.legend(loc='best')
        
plt.show()
plt.close()
```


    <Figure size 432x288 with 0 Axes>



    
![png](output_27_1.png)
    



```python
# 권역별 합계 추가, 내림차순 정렬
subset_frm['합계'] = subset_frm.sum(axis=1)
subset_frm = subset_frm[['합계']].sort_values('합계', ascending=False)
subset_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>합계</th>
    </tr>
    <tr>
      <th>전입지</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>충청남도</th>
      <td>359066.0</td>
    </tr>
    <tr>
      <th>강원도</th>
      <td>351462.0</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>235480.0</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>232070.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 권역별 합계가 가장 많은 권역값을 정렬 수평막대그래프로 시각화
subset_frm.plot(kind = 'bar',
               figsize = (15,5))

plt.xticks(rotation = 0)
plt.show()
plt.close()
```


    
![png](output_29_0.png)
    



```python
plt.figure(figsize = (15,5))
plt.bar(subset_frm.index,
       subset_frm['합계'].values)

plt.show()
plt.close()
```


    
![png](output_30_0.png)
    


- iris


```python
iris_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>145</th>
      <td>6.7</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.3</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>146</th>
      <td>6.3</td>
      <td>2.5</td>
      <td>5.0</td>
      <td>1.9</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>147</th>
      <td>6.5</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.0</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>148</th>
      <td>6.2</td>
      <td>3.4</td>
      <td>5.4</td>
      <td>2.3</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>149</th>
      <td>5.9</td>
      <td>3.0</td>
      <td>5.1</td>
      <td>1.8</td>
      <td>virginica</td>
    </tr>
  </tbody>
</table>
<p>150 rows × 5 columns</p>
</div>




```python
print('종을 기준으로 그룹화하여 각 그룹의 평균을 구해서 시각화 한다면? - ')
print('조건 rename - sepal_length -> 꽃받침길이 sepal_width -> 꽃받침넓이 petal_length -> 꽃잎길이 petal_width -> 꽃잎넓이')
print('kind - bar')
iris_frm.rename(columns = {'sepal_length':'꽃받침길이',
                           'sepal_width': '꽃받침넓이',
                          'petal_length': '꽃잎길이',
                          'petal_width': '꽃잎넓이',
                          'species' : 'Y'},
                inplace = True)
```

    종을 기준으로 그룹화하여 각 그룹의 평균을 구해서 시각화 한다면? - 
    조건 rename - sepal_length -> 꽃받침길이 sepal_width -> 꽃받침넓이 petal_length -> 꽃잎길이 petal_width -> 꽃잎넓이
    kind - bar
    


```python
iris_mean = iris_frm.groupby('Y').mean()
iris_mean
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>꽃받침길이</th>
      <th>꽃받침넓이</th>
      <th>꽃잎길이</th>
      <th>꽃잎넓이</th>
    </tr>
    <tr>
      <th>Y</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>setosa</th>
      <td>5.006</td>
      <td>3.428</td>
      <td>1.462</td>
      <td>0.246</td>
    </tr>
    <tr>
      <th>versicolor</th>
      <td>5.936</td>
      <td>2.770</td>
      <td>4.260</td>
      <td>1.326</td>
    </tr>
    <tr>
      <th>virginica</th>
      <td>6.588</td>
      <td>2.974</td>
      <td>5.552</td>
      <td>2.026</td>
    </tr>
  </tbody>
</table>
</div>




```python
iris_mean.plot(kind = 'bar',
               figsize = (15,5))
plt.xticks(rotation = 0)
plt.legend(loc='best')
        
plt.show()
plt.close()
```


    <Figure size 432x288 with 0 Axes>



    
![png](output_35_1.png)
    



```python
iris_mean = iris_mean.T
iris_mean
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Y</th>
      <th>setosa</th>
      <th>versicolor</th>
      <th>virginica</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>꽃받침길이</th>
      <td>5.006</td>
      <td>5.936</td>
      <td>6.588</td>
    </tr>
    <tr>
      <th>꽃받침넓이</th>
      <td>3.428</td>
      <td>2.770</td>
      <td>2.974</td>
    </tr>
    <tr>
      <th>꽃잎길이</th>
      <td>1.462</td>
      <td>4.260</td>
      <td>5.552</td>
    </tr>
    <tr>
      <th>꽃잎넓이</th>
      <td>0.246</td>
      <td>1.326</td>
      <td>2.026</td>
    </tr>
  </tbody>
</table>
</div>




```python
iris_mean.plot(kind = 'bar',
               figsize = (15,5))
plt.xticks(rotation = 0)
plt.legend(loc='best')
        
plt.show()
plt.close()
```


    
![png](output_37_0.png)
    



```python
iris_frm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>꽃받침길이</th>
      <th>꽃받침넓이</th>
      <th>꽃잎길이</th>
      <th>꽃잎넓이</th>
      <th>Y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>145</th>
      <td>6.7</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.3</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>146</th>
      <td>6.3</td>
      <td>2.5</td>
      <td>5.0</td>
      <td>1.9</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>147</th>
      <td>6.5</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.0</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>148</th>
      <td>6.2</td>
      <td>3.4</td>
      <td>5.4</td>
      <td>2.3</td>
      <td>virginica</td>
    </tr>
    <tr>
      <th>149</th>
      <td>5.9</td>
      <td>3.0</td>
      <td>5.1</td>
      <td>1.8</td>
      <td>virginica</td>
    </tr>
  </tbody>
</table>
<p>150 rows × 5 columns</p>
</div>




```python
iris_frm[['꽃잎길이', 'Y']].plot(by='Y')
```




    array([<AxesSubplot:>, <AxesSubplot:>, <AxesSubplot:>], dtype=object)




    
![png](output_39_1.png)
    



```python
iris_frm[['꽃잎길이', 'Y']].plot(by='Y', kind = 'box', figsize=(15,5))
```




    꽃잎길이    AxesSubplot(0.125,0.125;0.775x0.755)
    dtype: object




    
![png](output_40_1.png)
    


#### 남북한발전전력량.xlsx

- plot
- bar
- box
- frm.plot, bar, box


```python
tmp_frm = pd.read_excel('./data/visualization_data/남북한발전전력량.xlsx' ,
                       header = 0)
tmp_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>전력량 (억㎾h)</th>
      <th>발전 전력별</th>
      <th>1990</th>
      <th>1991</th>
      <th>1992</th>
      <th>1993</th>
      <th>1994</th>
      <th>1995</th>
      <th>1996</th>
      <th>1997</th>
      <th>...</th>
      <th>2007</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>남한</td>
      <td>합계</td>
      <td>1077</td>
      <td>1186</td>
      <td>1310</td>
      <td>1444</td>
      <td>1650</td>
      <td>1847</td>
      <td>2055</td>
      <td>2244</td>
      <td>...</td>
      <td>4031</td>
      <td>4224</td>
      <td>4336</td>
      <td>4747</td>
      <td>4969</td>
      <td>5096</td>
      <td>5171</td>
      <td>5220</td>
      <td>5281</td>
      <td>5404</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>수력</td>
      <td>64</td>
      <td>51</td>
      <td>49</td>
      <td>60</td>
      <td>41</td>
      <td>55</td>
      <td>52</td>
      <td>54</td>
      <td>...</td>
      <td>50</td>
      <td>56</td>
      <td>56</td>
      <td>65</td>
      <td>78</td>
      <td>77</td>
      <td>84</td>
      <td>78</td>
      <td>58</td>
      <td>66</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>화력</td>
      <td>484</td>
      <td>573</td>
      <td>696</td>
      <td>803</td>
      <td>1022</td>
      <td>1122</td>
      <td>1264</td>
      <td>1420</td>
      <td>...</td>
      <td>2551</td>
      <td>2658</td>
      <td>2802</td>
      <td>3196</td>
      <td>3343</td>
      <td>3430</td>
      <td>3581</td>
      <td>3427</td>
      <td>3402</td>
      <td>3523</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>원자력</td>
      <td>529</td>
      <td>563</td>
      <td>565</td>
      <td>581</td>
      <td>587</td>
      <td>670</td>
      <td>739</td>
      <td>771</td>
      <td>...</td>
      <td>1429</td>
      <td>1510</td>
      <td>1478</td>
      <td>1486</td>
      <td>1547</td>
      <td>1503</td>
      <td>1388</td>
      <td>1564</td>
      <td>1648</td>
      <td>1620</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>신재생</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>86</td>
      <td>118</td>
      <td>151</td>
      <td>173</td>
      <td>195</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
tmp_frm = tmp_frm.fillna(method = 'ffill')
tmp_frm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>전력량 (억㎾h)</th>
      <th>발전 전력별</th>
      <th>1990</th>
      <th>1991</th>
      <th>1992</th>
      <th>1993</th>
      <th>1994</th>
      <th>1995</th>
      <th>1996</th>
      <th>1997</th>
      <th>...</th>
      <th>2007</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>남한</td>
      <td>합계</td>
      <td>1077</td>
      <td>1186</td>
      <td>1310</td>
      <td>1444</td>
      <td>1650</td>
      <td>1847</td>
      <td>2055</td>
      <td>2244</td>
      <td>...</td>
      <td>4031</td>
      <td>4224</td>
      <td>4336</td>
      <td>4747</td>
      <td>4969</td>
      <td>5096</td>
      <td>5171</td>
      <td>5220</td>
      <td>5281</td>
      <td>5404</td>
    </tr>
    <tr>
      <th>1</th>
      <td>남한</td>
      <td>수력</td>
      <td>64</td>
      <td>51</td>
      <td>49</td>
      <td>60</td>
      <td>41</td>
      <td>55</td>
      <td>52</td>
      <td>54</td>
      <td>...</td>
      <td>50</td>
      <td>56</td>
      <td>56</td>
      <td>65</td>
      <td>78</td>
      <td>77</td>
      <td>84</td>
      <td>78</td>
      <td>58</td>
      <td>66</td>
    </tr>
    <tr>
      <th>2</th>
      <td>남한</td>
      <td>화력</td>
      <td>484</td>
      <td>573</td>
      <td>696</td>
      <td>803</td>
      <td>1022</td>
      <td>1122</td>
      <td>1264</td>
      <td>1420</td>
      <td>...</td>
      <td>2551</td>
      <td>2658</td>
      <td>2802</td>
      <td>3196</td>
      <td>3343</td>
      <td>3430</td>
      <td>3581</td>
      <td>3427</td>
      <td>3402</td>
      <td>3523</td>
    </tr>
    <tr>
      <th>3</th>
      <td>남한</td>
      <td>원자력</td>
      <td>529</td>
      <td>563</td>
      <td>565</td>
      <td>581</td>
      <td>587</td>
      <td>670</td>
      <td>739</td>
      <td>771</td>
      <td>...</td>
      <td>1429</td>
      <td>1510</td>
      <td>1478</td>
      <td>1486</td>
      <td>1547</td>
      <td>1503</td>
      <td>1388</td>
      <td>1564</td>
      <td>1648</td>
      <td>1620</td>
    </tr>
    <tr>
      <th>4</th>
      <td>남한</td>
      <td>신재생</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>...</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>86</td>
      <td>118</td>
      <td>151</td>
      <td>173</td>
      <td>195</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python

```
